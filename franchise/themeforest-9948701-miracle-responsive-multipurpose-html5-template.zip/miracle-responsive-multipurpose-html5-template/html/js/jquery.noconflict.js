sjq = jQuery.noConflict();
